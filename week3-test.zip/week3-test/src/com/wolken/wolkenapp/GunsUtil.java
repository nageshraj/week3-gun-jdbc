package com.wolken.wolkenapp;

import java.sql.SQLException;

import com.wolken.wolkenapp.DTO.GunsDTO;
import com.wolken.wolkenapp.service.GunsService;
import com.wolken.wolkenapp.service.GunsServiceImpl;

public class GunsUtil {

	public static void main(String[] args) throws SQLException {
		GunsDTO gunsDTO = new GunsDTO();
		GunsService gunsService = new GunsServiceImpl();

		gunsDTO.setGunsId(6);
		gunsDTO.setGunName("NEGECV");
		gunsDTO.setGunBrandName("boston");
		gunsDTO.setGunMadeIn("China");
		gunsDTO.setGunNoOfBullets(170);
		gunsDTO.setGunPrice(5600);
		gunsDTO.setGunSerialNumber("neg01");
		gunsDTO.setGunType("MG");
		//Adding
		if (gunsService.validateAndAddGun(gunsDTO))
			System.out.println("Gun Added");
		else
			System.out.println("gun not added");
		
		//Print all
		System.out.println("\nPrinting all data : ");
		gunsService.ValidateAndGetAll();
		
		
		//Delete by Id
		System.out.println("\nDeleting by Gun ID: ");
		gunsService.validateAndDeleteByGunsId(3);
		gunsService.ValidateAndGetAll();
		
		//Update by serial no
		gunsService.validateAndUpdateBySerialNumber("\nNEGEV", "neg01");
		gunsService.ValidateAndGetAll();
		
		//Get by Brand
		
		gunsService.validateAndGetAllByBrandName("Khalils");
		System.out.println();
		//Get by type
		gunsService.validateAndGetAllByType("rifle");
		
		
		
		
		

	}

}
