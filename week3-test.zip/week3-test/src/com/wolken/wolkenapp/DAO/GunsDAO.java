package com.wolken.wolkenapp.DAO;

import java.sql.SQLException;

import com.wolken.wolkenapp.DTO.GunsDTO;

public interface GunsDAO {

	public boolean AddGun(GunsDTO gunsDTO) throws SQLException;

	public void GetAll() throws SQLException;

	public void DeleteByGunsId(int gunsIdToBeDeleted) throws SQLException;

	public void UpdateBySerialNumber(String GunNameToUpdate, String gunSerialNumber) throws SQLException;

	public void GetAllByBrandName(String BrandName) throws SQLException;

	public void GetAllByType(String type) throws SQLException;

}
